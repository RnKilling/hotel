	<footer>
		<h6>Copyright &copy; 2024 | AKMAL-NENGAH-YUDA</h6>
	</footer>
</body>
</html>