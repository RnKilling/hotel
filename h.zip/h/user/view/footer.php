
	</center>	
		
	</main>
	<footer>
		<h6>Copyright &copy; 2018 | KELOMPOK YUDHAWWW</h6>
	</footer>
</body>
</html>
