# Sistem Informasi
Sistem Informasi Pemesanan Kamar Hotel Menggunakan PHP dan MySQL

Web Server : Xampp (Apache) 5.6.8
PHP : 5.5
DB : MySQL (koneksi PDO)
Library : - SweetAlert (Javascript) - FPDF (Laporan)

# Login Admin
  user & pass : admin
# Login User
  user: ali
  pass: 123
# Team Support
  Ali - Fahri - Inka - Furkan
